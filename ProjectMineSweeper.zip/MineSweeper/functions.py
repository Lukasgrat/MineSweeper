from tkinter import *
import random
class mines(object):
    def __init__(self,number,x,y):
        x = random.randint(1,10)
        if x != 1:
            self.mined = False
        else:
            self.mined = True
        self.cleared = False
        self.minenumber = number