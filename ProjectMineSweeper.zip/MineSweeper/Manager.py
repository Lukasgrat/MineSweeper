from MineSweeper.StartScreen import start
from MineSweeper.GameDisplay import minesweeper
from tkinter import *
class Screen_Manager(object):
    def __init__(self):
        self.root = Tk()
        self.currentScreen = None
        self.wl = None
    def start_screen(self):
        self.root.title("Main Menu")
        self.currentScreen = start(self.root,self.startup_screengame)
    def startup_screengame(self):
        self.currentScreen.destroy()
        self.root.title("Mine Sweeper")
        self.currentScreen = minesweeper(self.root,self.ending_screen)
    def ending_screen(self,wl):
        self.currentScreen.destroy()
        self.root.destroy()
def main():
    game = Screen_Manager()
    game.start_screen()
    game.root.mainloop()
main()