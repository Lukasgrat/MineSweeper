from tkinter import *
from MineSweeper import functions


class minesweeper(Frame):
    def __init__(self,master,closefile1):
        super().__init__(master)
        self.grid()
        self.buttonlist = []
        self.minestart()
        self.button = 0
        self.closefile1 = closefile1
        self.wl = None
    def minestart(self):
        x = 0
        Label(self,
              text="Flagging, type in coordinates like this: x,y"
              ).grid(row=9, column=21, sticky=N)
        self.coords = Entry(self)
        self.coords.grid(row=10, column=21, sticky=N)
        self.coordbutton = Button(self,text="Place Flag",command = self.place)
        self.coordbutton.grid(row=11,column=21)
        for r in range(0, 20):
            for c in range(0,20):
                mine = functions.mines(x, r, c)
                self.buttonlist.append(mine)
                Buttons =Button(self,text="",command = self.minecheck_factory(r,c) ,width=2,height=1)
                oddcheck = r + c
                if oddcheck % 2 == 1:
                    Buttons["bg"] = "light gray"
                Buttons.grid(row=r ,column=c,sticky = N)
                x += 1
    def minecheck_factory(self, r, c):
        return  lambda: self.minecheck(c, r)
    def minecheck(self,column,row):
        alpha = 20*row + column
        check = 0
        if self.buttonlist[alpha].mined == False:
            surround = self.checksurround(alpha)
            self.replace(surround, alpha)
            self.buttonlist[alpha].cleared = True
            for x in self.buttonlist:
                if x.mined == False and x.cleared == False:
                    check += 1
            if check == 0:
                self.wl = False
        else:
            self.wl = True
            self.winlose()
    def checksurround(self,alpha):
        surround = 0
        if alpha % 20 >0:
            if self.buttonlist[alpha-1].mined == True:
                surround += 1
        if alpha % 20 < 19:
            if self.buttonlist[alpha+1].mined == True:
                surround += 1
        if alpha >19:
            if self.buttonlist[alpha - 20].mined == True:
                surround += 1
        if alpha < 380:
            if self.buttonlist[alpha + 20].mined == True:
                surround += 1
        return surround
    def replace(self,surround,alpha):
        x = alpha // 20
        y = alpha % 20
        Label(self,text = str(surround), width=2, height=1).grid(row =x,column = y)
    def place(self):
        coords = self.coords.get()
        coords = coords.split(",")
        if len(coords) != 2:
            Label(self,text = "Invalid Input, please put it in as shown above",fg ="red"
                  ).grid(row =8,column = 13)
        else:
            x = coords[0]
            y = coords[1]
            x = int(x)
            y = int(y)
            Buttons = Button(self, text="F",fg = "red", command=self.minecheck_factory(y,x), width=2, height=1)
            Buttons.grid(row=y, column=x, sticky=N)
    def winlose(self):
        if self.wl != False:
            Label(self, text="You Lose!, Run the Program again to try again.", bg="red").grid(row=21, column=0,sticky=N,columnspan = 12)
        elif self.wl != True:
            Label(self, text="You Win!, Run the Program again to try again.",fg = "white",bg="blue").grid(row=21, column=0,sticky=N,columnspan = 12)
        Button(text ="Quit",command = self.Quit).grid(row = 22,column = 0,sticky =N,columnspan = 12)
    def Quit(self):
        self.closefile1(self.wl)