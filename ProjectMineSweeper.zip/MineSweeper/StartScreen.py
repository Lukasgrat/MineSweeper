from tkinter import *
class start(Frame):
    def __init__(self,master,linkup):
        super(start, self).__init__(master)
        self.linkup = linkup
        self.grid(rowspan=20,columnspan=50)
        self.create_widgets()
    def create_widgets(self):
        Label(self,text = "Welcome to Mine Sweeper",font =30,fg = "blue",).grid(sticky = N,row = 1,column = 0)
        Label(self,text = "Prepare to Sweep!",font =18,fg = "green").grid(sticky = N, row = 2,column = 0)
        Button(self,text="Sweep",font = 24,command=self.link,fg ="red").grid(sticky = N,row = 3, column = 0)
    def link(self):
        self.linkup()